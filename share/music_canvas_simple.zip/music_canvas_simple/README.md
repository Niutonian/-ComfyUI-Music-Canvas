# music_canvas_simple

Extract this folder into Block Party's jobs/ directory. Install Block Party. Models and custom-node code are not included in this ZIP. Preparation installs missing dependencies when their sources are supplied and you confirm the plan. Start ComfyUI, then from the Block Party folder run:

```powershell
python -m one_job link
python -m one_job prepare jobs/music_canvas_simple
python -m one_job runweb jobs/music_canvas_simple
```

Drop one audio into input/. Any filename works. Slot audio_0 (LoadAudio 20).

Edit matching .txt files in input/ to change individual prompts. Preparation is local to each recipient's computer.

For gated downloads, use the one-time password fields in runweb or run `python -m one_job credentials` to locate the machine-local downloads.env file. Never share API keys. Use prepare --restart or the browser restart option to continue after installing nodes. Missing download URLs must be supplied by the author; conflicting files are never replaced.


## Music Canvas export notes

# music_canvas_simple

Direct prompt-driven rendering: audio → selected range → H3 with your written visual prompt → preview/SaveVideo. No MOSS, Beat This, Ollama or story planning. Longer ranges reuse the supplied prompt across segments; use the directed sequential example for narrative development.

Saved at 15 seconds, start 0, 15-second segments, 0.3 MP at 2:3, 8 steps. Sequential rendering rounds dimensions down to multiples of 16. Models: Singularity INT8, Qwen NVFP4/AWQ encoder, both H3 VAEs, 4-step turbo LoRA at 0.8 and Better Motion at 0.74. The LoRA name does not force the sampler's step count; eight is retained from the original graph.

Load `workflow.json`, select your audio and edit the multiline prompt. Its generic sample replaces a private recovered prompt. The project label is `music_canvas_simple`; run folders receive revisions automatically. Matching inputs can resume. The native VIDEO output is connected to SaveVideo.

The matching Block Party ZIP has one audio slot, one video output and six verified model downloads. Music Canvas and external node code are pinned to published commits, so its dependency sources are ready for Block Party preparation. FFmpeg, the compatible host/loaders, hardware and model permissions are required. No audio is included; the user's saved original was not modified.


Music Canvas source: https://github.com/Niutonian/-ComfyUI-Music-Canvas.git

Model rights are separate from this job. MiniMax H3 has a restricted community license, including territorial exclusions. Read https://huggingface.co/MiniMaxAI/MiniMax-H3/blob/main/LICENSE before downloading or using its weights. Derivative model-card badges do not establish unrestricted rights. No weights or music are bundled. Original Music Canvas source and documentation are MIT-licensed; model terms remain separate.

For the analysis examples, install/check an isolated audio candidate with `uv run python setup_runtime.py --install-environment`, explicitly download the pinned MOSS snapshot using the configured Python and `audio_assets.py --models-root <ComfyUI/models>`, and run local Ollama with a compatible model selected in the graph. The `ornith-1.5:35b` name is a local alias: the full repository provides a pinned public GGUF and Modelfile. Block Party does not install that service or import that model for you. The legacy runtime has known advisories, and installing and fully validating the patched candidate remains pending; read SECURITY.md in the source repository.


## Music Canvas license

MIT License

Copyright (c) 2026 Niutonian

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
