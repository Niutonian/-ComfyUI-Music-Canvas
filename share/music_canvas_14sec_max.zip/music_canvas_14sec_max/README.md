# music_canvas_14sec_max

Extract this folder into Block Party's jobs/ directory. Install Block Party. Models and custom-node code are not included in this ZIP. Preparation installs missing dependencies when their sources are supplied and you confirm the plan. Start ComfyUI, then from the Block Party folder run:

```powershell
python -m one_job link
python -m one_job prepare jobs/music_canvas_14sec_max
python -m one_job runweb jobs/music_canvas_14sec_max
```

Drop one audio into input/. Any filename works. Slot audio_0 (LoadAudio 20).

Edit matching .txt files in input/ to change individual prompts. Preparation is local to each recipient's computer.

For gated downloads, use the one-time password fields in runweb or run `python -m one_job credentials` to locate the machine-local downloads.env file. Never share API keys. Use prepare --restart or the browser restart option to continue after installing nodes. Missing download URLs must be supplied by the author; conflicting files are never replaced.


## Music Canvas export notes

# music_canvas_14sec_max

Single-clip workflow: audio → frame-calculated excerpt → quick music analysis → Ollama concept/prompt → unload Ollama → audio-guided H3 → decode → two SaveVideo outputs (original audio and silent). No long-form story planner/editor.

Despite its name, the saved graph requests **8 seconds**. The calculator snaps to native `(17j+5)/24` durations at 24 fps; eight seconds is exactly 192 frames. The filename is not a hardcoded 14-second limit. Near 14 seconds, choose rounding deliberately and keep actual duration within the director's 15-second social-preview maximum.

Saved at start 0, 0.8 MP at 2:3, 8 steps, 4-step turbo LoRA at 0.8 and Better Motion at 0.65. Longer/higher-resolution clips increase memory use. The external MMH3Tools frame calculator is pinned in the manifest; its unresolved source-license status is documented in the license review.

`concept_index=0` and both style dropdowns at `none` retain music-guided automatic selection. Shared transcription/approval and downloads are off. Select your audio in `workflow.json`; follow the main README for runtime/models/Ollama.

The matching Block Party ZIP exposes one audio input, two video outputs and seven verified model references including Beat This. Music Canvas has a published source pin. MOSS snapshot/runtime and Ollama setup are separate prerequisites, so `readiness.json` still marks manual setup. No input song is shared, and the user's original graph was not altered.


Music Canvas source: https://github.com/Niutonian/-ComfyUI-Music-Canvas.git

Model rights are separate from this job. MiniMax H3 has a restricted community license, including territorial exclusions. Read https://huggingface.co/MiniMaxAI/MiniMax-H3/blob/main/LICENSE before downloading or using its weights. Derivative model-card badges do not establish unrestricted rights. No weights or music are bundled. Original Music Canvas source and documentation are MIT-licensed; model terms remain separate.

For the analysis examples, install/check an isolated audio candidate with `uv run python setup_runtime.py --install-environment`, explicitly download the pinned MOSS snapshot using the configured Python and `audio_assets.py --models-root <ComfyUI/models>`, and run local Ollama with a compatible model selected in the graph. The `ornith-1.5:35b` name is a local alias: the full repository provides a pinned public GGUF and Modelfile. Block Party does not install that service or import that model for you. The legacy runtime has known advisories, and installing and fully validating the patched candidate remains pending; read SECURITY.md in the source repository.


## Music Canvas license

MIT License

Copyright (c) 2026 Niutonian

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
