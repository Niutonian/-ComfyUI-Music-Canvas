# music_canvas_start_here

Extract this folder into Block Party's jobs/ directory. Install Block Party. Models and custom-node code are not included in this ZIP. Preparation installs missing dependencies when their sources are supplied and you confirm the plan. Start ComfyUI, then from the Block Party folder run:

```powershell
python -m one_job link
python -m one_job prepare jobs/music_canvas_start_here
python -m one_job runweb jobs/music_canvas_start_here
```

Drop one audio into input/. Any filename works. Slot audio_0 (LoadAudio 20).

Edit matching .txt files in input/ to change individual prompts. Preparation is local to each recipient's computer.

For gated downloads, use the one-time password fields in runweb or run `python -m one_job credentials` to locate the machine-local downloads.env file. Never share API keys. Use prepare --restart or the browser restart option to continue after installing nodes. Missing download URLs must be supplied by the author; conflicting files are never replaced.


## Music Canvas export notes

# music_canvas_start_here

Open [music_canvas_start_here.json](music_canvas_start_here.json) in ComfyUI and load your own song. Queue once to render the first 12 seconds as two 6-second clips with visual continuity at 0.25 MP and eight steps. Lyrics transcription is off. Follow the [installation guide](../../README.md) for the models and Ollama setup.


Music Canvas source: Not assigned yet: install the reviewed Music Canvas source manually; do not substitute ComfyUI as its repository.

Model rights are separate from this job. MiniMax H3 has a restricted community license, including territorial exclusions. Read https://huggingface.co/MiniMaxAI/MiniMax-H3/blob/main/LICENSE before downloading or using its weights. Derivative model-card badges do not establish unrestricted rights. No weights or music are bundled. Original Music Canvas source and documentation are MIT-licensed; model terms remain separate.

For the analysis examples, install/check an isolated audio candidate with `uv run python setup_runtime.py --install-environment`, explicitly download the pinned MOSS snapshot using the configured Python and `audio_assets.py --models-root <ComfyUI/models>`, and run local Ollama with a compatible model selected in the graph. The `ornith-1.5:9b` name is a local alias. The main README explains how to install it. Block Party does not install that service or import that model for you. The legacy runtime has known advisories, and installing and fully validating the patched candidate remains pending; read SECURITY.md in the source repository.


## Music Canvas license

MIT License

Copyright (c) 2026 Niutonian

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
