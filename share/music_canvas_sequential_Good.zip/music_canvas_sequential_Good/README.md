# music_canvas_sequential_Good

Extract this folder into Block Party's jobs/ directory. Install Block Party. Models and custom-node code are not included in this ZIP. Preparation installs missing dependencies when their sources are supplied and you confirm the plan. Start ComfyUI, then from the Block Party folder run:

```powershell
python -m one_job link
python -m one_job prepare jobs/music_canvas_sequential_Good
python -m one_job runweb jobs/music_canvas_sequential_Good
```

Drop one audio into input/. Any filename works. Slot audio_0 (LoadAudio 20).

Edit matching .txt files in input/ to change individual prompts. Preparation is local to each recipient's computer.

For gated downloads, use the one-time password fields in runweb or run `python -m one_job credentials` to locate the machine-local downloads.env file. Never share API keys. Use prepare --restart or the browser restart option to continue after installing nodes. Missing download URLs must be supplied by the author; conflicting files are never replaced.


## Music Canvas export notes

# music_canvas_sequential_Good

Audio → selected range → MOSS-Music/Beat This → six concepts → story planner/editor → scene timeline → sequential H3 rendering → preview/SaveVideo. Save Analysis and Prompt records creative artifacts locally for inspection.

Saved at start 0, total 60 seconds, 15-second segments, Detailed music/full coverage analysis with CPU beats, 0.3 MP at 2:3, 8 steps. Models include the 8-step turbo LoRA at 0.8 and Better Motion at 0.74. Renderer seed is 42. Director/story seeds are retained; the director UI randomizes its seed between queued runs.

`concept_index=0` and both category dropdowns at `none` preserve music-guided automatic selection. Analysis is reused until relevant inputs/settings change or `reanalyze` is incremented. The story/timeline develops distinct scenes; separate H3 renders still cannot guarantee character identity or seamless boundaries. Audio guidance is not exact beat lock.

For a full song, consult the timing node's tooltip: total length 0 selects the remaining audio. There is no one-clip total-duration limit; resources and planning limits apply. All branches share the same selected range.

Shared transcription/lyric approval and automatic-download switches are off. Select your audio and follow the main README's audio-runtime/model/Ollama setup. The Block Party ZIP has one audio slot, one video output and seven verified model references including the explicitly mapped Beat This checkpoint. Music Canvas has a published source pin. MOSS's folder snapshot, the audio runtime and Ollama remain separate setup requirements listed in `readiness.json`.

Private audio names, lyrics/preview text and project labels are removed. Original saved workflows remain untouched.


Music Canvas source: https://github.com/Niutonian/-ComfyUI-Music-Canvas.git

Model rights are separate from this job. MiniMax H3 has a restricted community license, including territorial exclusions. Read https://huggingface.co/MiniMaxAI/MiniMax-H3/blob/main/LICENSE before downloading or using its weights. Derivative model-card badges do not establish unrestricted rights. No weights or music are bundled. Original Music Canvas source and documentation are MIT-licensed; model terms remain separate.

For the analysis examples, install/check an isolated audio candidate with `uv run python setup_runtime.py --install-environment`, explicitly download the pinned MOSS snapshot using the configured Python and `audio_assets.py --models-root <ComfyUI/models>`, and run local Ollama with a compatible model selected in the graph. The `ornith-1.5:35b` name is a local alias: the full repository provides a pinned public GGUF and Modelfile. Block Party does not install that service or import that model for you. The legacy runtime has known advisories, and installing and fully validating the patched candidate remains pending; read SECURITY.md in the source repository.


## Music Canvas license

MIT License

Copyright (c) 2026 Niutonian

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
